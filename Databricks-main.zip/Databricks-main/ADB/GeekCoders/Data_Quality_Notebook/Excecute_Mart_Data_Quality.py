# Databricks notebook source
# MAGIC %run /GeekCoders/Utlilities

# COMMAND ----------

excecute_test_case("mart_geekcoders")
